# Simple chat bot example

This example demonstrates simple 1-to-1 chat bot. It can simply echo incoming messages.

# Guide
Read Chat Bots guide to understand how to build own bot for QuickBlox.

[https://quickblox.com/developers/ChatBots](https://quickblox.com/developers/ChatBots)
